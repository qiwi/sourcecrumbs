import { TVerifyOptions, TPackageRef, TRepoRef, TAttestation } from './interface';
export declare const verifyPkg: ({ name, version, registry }: TVerifyOptions) => Promise<{
    entries: Record<string, any>;
    meta: {
        repoRef: TRepoRef;
        pkgRef: {
            name: string;
            version: string;
            registry: string;
        };
    };
}>;
export declare const extractPayload: <D = any>(v: string) => D;
export declare const getAttestation: ({ name, version, registry }: TPackageRef) => Promise<Record<string, TAttestation>>;
export declare const formatRepoUrl: (rawRepositoryUrl: string) => string;
export declare const formatAttestationUrl: ({ registry, name, version }: TPackageRef) => string;
export declare const formatPackumentUrl: ({ registry, name, version }: TPackageRef) => string;
export declare const formatTarballUrl: ({ registry, name, version }: TPackageRef) => string;
export declare const fetchAttestation: (pkgRef: TPackageRef) => Promise<any>;
export declare const fetchPackument: (pkgRef: TPackageRef) => Promise<any>;
export declare const fetchCommit: ({ repo, commit, cwd }: {
    repo: string;
    commit: string;
    cwd?: string | undefined;
}) => Promise<string>;
export declare const fetchPkg: ({ name, version, registry, cwd }: TPackageRef & {
    cwd?: string | undefined;
}) => Promise<Record<string, string>>;
export declare const fetchSources: ({ url, hash }: TRepoRef) => Promise<Record<string, string>>;
export declare const readFiles: (cwd: string, absolute?: boolean) => Promise<Record<string, string>>;
