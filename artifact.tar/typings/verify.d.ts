import { TSourcemap, TVerifyContext } from './interface';
export declare const verifyFiles: ({ name, targets, sources }: {
    name: string;
    targets: Record<string, string>;
    sources?: Record<string, string> | undefined;
}) => Record<string, any>;
export declare const findPkgRoot: ({ sources, name, cwd }: {
    sources: Record<string, string>;
    name: string;
    cwd?: string | undefined;
}) => string;
export declare const findSourcemap: ({ name, targets, sources, root }: TVerifyContext) => {
    sources: string[];
    valid: boolean;
    coherence: number | null;
} | null;
export declare const findSource: ({ name, targets, sources, root }: TVerifyContext) => {
    sources: string[];
    coherence: number;
} | null;
export declare const getDiffCoherence: (a: string, b: string) => number;
export declare const getBundleCoherence: ({ name, contents, sources, sourcemap }: {
    name: string;
    contents: string;
    sources: Record<string, string>;
    sourcemap: TSourcemap;
}) => number | null;
export declare const validateSourcemap: (contents: string, sourceMap?: string | null, sources?: Record<string, string>) => boolean;
